﻿using System;
using System.Collections.Generic;
using System.Text;
using Ex03.GarageLogic;

namespace Ex03.ConsoleUI
{
    public class MenuWizrad
    {
        public Garage Garage = new Garage();
        public NewVehicleGenerator NewVehicelGen = new NewVehicleGenerator();

        public void MainMenu()
        {
            while (true)
            {
                try
                {
                    printMainMenu();
                    string input = Console.ReadLine();
                    int select = int.Parse(input);
                    switch (select)
                    {
                        case 1:
                            getInputAndAddNewCar();
                            break;
                        case 2:
                            showListOfLicenseByStatus();
                            break;
                        case 3:
                            changeVehicleStatus();
                            Console.WriteLine("#Done");
                            break;
                        case 4:
                            wheelsInflatingToMax();
                            Console.WriteLine("#Done");
                            break;
                        case 5:
                            refuelVehicle();
                            Console.WriteLine("#Done");
                            break;
                        case 6:
                            chargeBattery();
                            Console.WriteLine("#Done");
                            break;
                        case 7:
                            showVehicleFullDetails();
                            break;
                        default:
                            Console.WriteLine("Wrong input");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    continue;
                }
                finally
                {
                    Console.WriteLine("--> Press any key to Main Menu");
                    Console.ReadKey();
                    Console.Clear();
                }
            }
        }

        private void chargeBattery()
        {
            Console.Write("-> Enter license number:");
            string licenseNumber = Console.ReadLine();
            Console.Write("-> Enter amount (in Minutes): ");
            float incomeMinutes = float.Parse(Console.ReadLine());
            Garage.Charge(licenseNumber, incomeMinutes);
        }

        private void refuelVehicle()
        {
            Console.Write("-> Enter license number:");
            string licenseNumber = Console.ReadLine();
            Console.Write("-> Enter fuel Type (1)Octan98 (2)Octan96 (3)Octan95 (4)Soler: ");
            efuelType incomeFuel = getFuelTypeInput();
            Console.Write("-> Enter amount (in Liters): ");
            float incomeLiters = float.Parse(Console.ReadLine());
            Garage.Refuel(licenseNumber, incomeFuel, incomeLiters);
        }

        private void showVehicleFullDetails()
        {
            Console.Write("-> Enter license number:");
            string licenseNumber = Console.ReadLine();
            Console.WriteLine("{0}", Garage.GetFullInfoOfVehicel(licenseNumber));
        }

        private void wheelsInflatingToMax()
        {
            Console.Write("-> Enter license number:");
            string licenseNumber = Console.ReadLine();
            Garage.AddAirPressureToMax(licenseNumber);
        }

        private efuelType getFuelTypeInput()
        {
            efuelType fuel;
            while (true)
            {
                int intFuel;
                try
                {
                    do
                    {
                        intFuel = int.Parse(Console.ReadLine());
                        if (intFuel > 4 || intFuel < 1)
                        {
                            Console.WriteLine("Wrong input, enter 1-4");
                        }
                    }
                    while (!(intFuel < 4 && intFuel > 0));
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    continue;
                }

                fuel = (efuelType)intFuel;
                break;
            }

            return fuel;
        }

        private eVehicleStatus getStatusInput()
        {
            eVehicleStatus status;
            while (true)
            {
                int intStatus;
                try
                {
                    do
                    {
                        intStatus = int.Parse(Console.ReadLine());
                        if (intStatus > 3 || intStatus < 1)
                        {
                            Console.WriteLine("Wrong input, enter 1-3");
                        }
                    }
                    while (!(intStatus < 4 && intStatus > 0));
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    continue;
                }

                status = (eVehicleStatus)intStatus;
                break;
            }

            return status;
        }

        private void changeVehicleStatus()
        {
            Console.Write("-> Enter license number:");
            string licenseNumber = Console.ReadLine();
            Console.Write("->Enter new status (1)InRepair (2)Fixed (3)Paid: ");
            eVehicleStatus newStatus = getStatusInput();
            Garage.ChangeVehicleStatus(licenseNumber, newStatus);
        }

        private void showListOfLicenseByStatus()
        {
            Console.Write("->Show List Of (1)InRepair (2)Fixed (3)Paid: ");
            eVehicleStatus status = getStatusInput();
            Console.WriteLine("-- {0} list --{1}{2}", status, Environment.NewLine, Garage.GetLicenseNumberByStatus(status));
        }

        private void getInputAndAddNewCar()
        {
            try
            { 
            Vehicle newVehicelToAdd;
            Console.Write("->Enter license number: ");
            string licenseNumber = Console.ReadLine();
            string modelName, clientName, clientPhone, weelsManufacturer;
            float weelsCurrentAirPressure;
                if (Garage.VehicleIsInGarage(licenseNumber))
                {
                    Garage.ChangeVehicleStatus(licenseNumber, eVehicleStatus.InRepair);
                    Console.WriteLine("Vehicel details is already in the system, status change to: InReapair");
                }
                else
                {
                    Console.Write("->Enter model name: ");
                    modelName = Console.ReadLine();
                    Console.Write("->Enter Weels manufacturer: ");
                    weelsManufacturer = Console.ReadLine();
                    Console.Write("->Enter Weels air pressure: ");
                    weelsCurrentAirPressure = float.Parse(Console.ReadLine());
                    Console.Write("->Enter client name: ");
                    clientName = Console.ReadLine();
                    Console.Write("->Enter client phone: ");
                    clientPhone = Console.ReadLine();
                    Console.Write("->Vehicle Driven by [(1)Fuel (2)Electric]: ");
                    int intEnergytype = int.Parse(Console.ReadLine());
                    while (!(intEnergytype > 0 && intEnergytype < 3))
                    {
                        Console.Write("Wrong input, enter 1 or 2: ");
                        intEnergytype = int.Parse(Console.ReadLine());
                    }

                    eEnergyMenuType Energytype = (eEnergyMenuType)intEnergytype;
                    switch (Energytype)
                    {
                        case eEnergyMenuType.Fuel:
                            Console.Write("->Enter current fuel level (Liter): ");
                            float currentFuelLevel = float.Parse(Console.ReadLine());
                            Console.Write("->Enter vehicle Type [(1)Car (2)Motorcycle (3)Truck]: ");
                            int intVehicletype = int.Parse(Console.ReadLine());
                            while (!(intVehicletype > 0 && intVehicletype < 4))
                            {
                                Console.Write("Wrong input, enter 1-3: ");
                                intVehicletype = int.Parse(Console.ReadLine());
                            }

                            eVehicleMenuType Vehicletype = (eVehicleMenuType)intVehicletype;
                            switch (Vehicletype)
                            {
                                case eVehicleMenuType.Car:
                                    eNumOfDoors NumOfDoors = getCarNumOfDoor();
                                    eCarColor CarColor = getCarColor();
                                    newVehicelToAdd = NewVehicelGen.AddNewFuelCar(CarColor, NumOfDoors, currentFuelLevel, modelName, licenseNumber, weelsCurrentAirPressure, clientName, clientPhone, weelsManufacturer);
                                    Garage.AddVehicleToGarage(newVehicelToAdd);
                                    break;
                                case eVehicleMenuType.Motorcycle:
                                    eMotorcycleLicenseType MotoLicenseType = getMotoLicenseType();
                                    int EngineCapacity = getEngineCapacity();
                                    newVehicelToAdd = NewVehicelGen.AddNewFuelMotorcycle(MotoLicenseType, EngineCapacity, currentFuelLevel, modelName, licenseNumber, weelsCurrentAirPressure, clientName, clientPhone, weelsManufacturer);
                                    Garage.AddVehicleToGarage(newVehicelToAdd);
                                    break;
                                case eVehicleMenuType.Truck:
                                    bool truckIsCoold = getIsTruckCooled();
                                    float cargoVolume = getCargoVolume();
                                    newVehicelToAdd = NewVehicelGen.AddNewFuelTruck(truckIsCoold, cargoVolume, currentFuelLevel, modelName, licenseNumber, weelsCurrentAirPressure, clientName, clientPhone, weelsManufacturer);
                                    Garage.AddVehicleToGarage(newVehicelToAdd);
                                    break;
                            }

                            break;
                        case eEnergyMenuType.Electric:
                            Console.Write("->Enter current battery level (Hours left): ");
                            float currentBatteryLevel = float.Parse(Console.ReadLine());
                            Console.Write("->Enter vehicle Type [(1)Car (2)Motorcycle]: ");
                            intVehicletype = int.Parse(Console.ReadLine());
                            while (!(intVehicletype > 0 && intVehicletype < 3))
                            {
                                Console.Write("Wrong input, enter 1-2: ");
                                intVehicletype = int.Parse(Console.ReadLine());
                            }

                            Vehicletype = (eVehicleMenuType)intVehicletype;
                            switch (Vehicletype)
                            {
                                case eVehicleMenuType.Car:
                                    eNumOfDoors NumOfDoors = getCarNumOfDoor();
                                    eCarColor CarColor = getCarColor();
                                    newVehicelToAdd = NewVehicelGen.AddElectricCar(CarColor, NumOfDoors, currentBatteryLevel, modelName, licenseNumber, weelsCurrentAirPressure, clientName, clientPhone, weelsManufacturer);
                                    Garage.AddVehicleToGarage(newVehicelToAdd);
                                    break;
                                case eVehicleMenuType.Motorcycle:
                                    eMotorcycleLicenseType MotoLicenseType = getMotoLicenseType();
                                    int EngineCapacity = getEngineCapacity();
                                    newVehicelToAdd = NewVehicelGen.AddElectricMotorcycle(MotoLicenseType, EngineCapacity, currentBatteryLevel, modelName, licenseNumber, weelsCurrentAirPressure, clientName, clientPhone, weelsManufacturer);
                                    Garage.AddVehicleToGarage(newVehicelToAdd);
                                    break;
                            }

                            break;
                    }
                }

                Console.WriteLine("*~* Vehicel has been added to reapir *~*");
            }
            catch (ValueOutOfRangeException voore)
            {
                Console.WriteLine("## Value Error - Vehicel not added: {0}{1}", Environment.NewLine, voore.Message);
            }
        }

        private float getCargoVolume()
        {
            Console.Write("->Enter cargo volume: ");
            float cargoVolume = float.Parse(Console.ReadLine());
            while (cargoVolume < 0)
            {
                Console.Write("Wrong input, enter a positive number: ");
                cargoVolume = float.Parse(Console.ReadLine());
            }

            return cargoVolume;
        }

        private bool getIsTruckCooled()
        {
            bool isCooled = false;
            Console.Write("-> Is Refrigerated cargo? [(1)Yes (2)No]: ");
            string strIsCooled = Console.ReadLine();
            while (strIsCooled != "1" && strIsCooled != "2")
            {
                Console.Write("Wrong input, enter 1-4: ");
                strIsCooled = Console.ReadLine();
            }

            isCooled = strIsCooled == "1" ? true : false;
            return isCooled;
        }

        private int getEngineCapacity()
        {
            Console.Write("->Enter engine capacity (cc): ");
            int intEngineCapacity = int.Parse(Console.ReadLine());
            while (intEngineCapacity < 0)
            {
                Console.Write("Wrong input, enter a positive number: ");
                intEngineCapacity = int.Parse(Console.ReadLine());
            }

            return intEngineCapacity;
        }

        private eMotorcycleLicenseType getMotoLicenseType()
        {
            Console.Write("->Enter license type [(1)A (2)A1 (3)B1 (4)B2]: ");
            int intType = int.Parse(Console.ReadLine());
            while (!(intType > 0 && intType < 5))
            {
                Console.Write("Wrong input, enter 1-4: ");
                intType = int.Parse(Console.ReadLine());
            }

            return (eMotorcycleLicenseType)intType;
        }

        private eCarColor getCarColor()
        {
            Console.Write("->Enter the color of the car[(1)Grey (2)Blue (3)White (4)Black]: ");
            int intCarColor = int.Parse(Console.ReadLine());
            while (!(intCarColor > 0 && intCarColor < 5))
            {
                Console.Write("Wrong input, enter 1-4: ");
                intCarColor = int.Parse(Console.ReadLine());
            }

            return (eCarColor)intCarColor;
        }

        private eNumOfDoors getCarNumOfDoor()
        {
            Console.Write("->Enter the number of doors [2 - 5]: ");
            int intNumOfDoors = int.Parse(Console.ReadLine());
            while (!(intNumOfDoors > 1 && intNumOfDoors < 6))
            {
                Console.Write("Wrong input, enter 2-5: ");
                intNumOfDoors = int.Parse(Console.ReadLine());
            }

            return (eNumOfDoors)intNumOfDoors;
        }

        private void printMainMenu()
        {
            Console.Write(@"- Garage management system -
1- Add new Vehicel to garage
2- Show list of vehicles in the garage (filterd by status)
3- Change vehicle's status
4- Wheels inflating to maximum
5- Refueling a fuel vehicle
6- Charge an electric vehicle
7- Show full details of vehicle
-> Enter your choice: ");
        }
    }
}
