﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public enum eMotorcycleLicenseType
    {
        A = 1, A1, B1, B2
    }
}
