﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
     public abstract class ElectricVehicle : Vehicle
    {
        private readonly float m_MaxBatteryHours;
        private float m_CurrentBatteryLeftHours;

        public ElectricVehicle(float i_CurrentBatteryLeftHours, float i_MaxBatteryHours, string i_ModelName, string i_LicenseNumber, float i_WeelsAirPressure, string i_OwnerName, string i_OwnwerPhone, int i_numOfWeels, string i_WeelManufacturerName, int i_WeelMaxAirPressure)
            : base(i_ModelName, i_LicenseNumber, i_WeelsAirPressure, i_OwnerName, i_OwnwerPhone, i_numOfWeels, i_WeelManufacturerName, i_WeelMaxAirPressure)
        {
            m_MaxBatteryHours = i_MaxBatteryHours;
            CurrentBatteryLeftHours = i_CurrentBatteryLeftHours;
        }

        public float CurrentBatteryLeftHours
        {
            get
            {
                return m_CurrentBatteryLeftHours;
            }

            set
            {
                if (value > m_MaxBatteryHours || value < 0)
                {
                    throw new ValueOutOfRangeException("Battery", 0, m_MaxBatteryHours);
                }
                else
                {
                    m_CurrentBatteryLeftHours = value;
                    base.EnergyPrecent = value * (100 / m_MaxBatteryHours);
                }
            }
        }

        public void ChargeBattery(float i_HoursToAdd)
        {
            CurrentBatteryLeftHours += i_HoursToAdd;
        }

        protected string getInfo()
        {
            return string.Format(
                @"{0}-- Electrinc unit information --
Battery estimated time remining: {1} hours ({2} maximum)", 
                base.getInfo(), 
                m_CurrentBatteryLeftHours,
                m_MaxBatteryHours);
        }
    }
}
