﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public enum eVehicleStatus
    {
        InRepair = 1, Fixed, Paid
    }

    public abstract class Vehicle
    {
        private string m_ModelName;
        private string m_LicenseNumber;
        private float m_EnergyPercent;
        private List<Weel> m_Weels;
        private eVehicleStatus m_VehicleStatus;
        private Client m_ClientOwner;
       
        public Vehicle(string i_ModelName, string i_LicenseNumber, float i_WeelsAirPressure, string i_OwnerName, string i_OwnwerPhone, int i_NumOfWeels, string i_WeelManufacturerName, int i_WeelMaxAirPressure)
        {
            m_ModelName = i_ModelName;
            LicenseNumber = i_LicenseNumber;
            m_ClientOwner = new Client(i_OwnerName, i_OwnwerPhone);
            initWeelList(i_NumOfWeels, i_WeelsAirPressure, i_WeelManufacturerName, i_WeelMaxAirPressure);
            ThisVehicleStatus = eVehicleStatus.InRepair;
        }
        
        public float EnergyPrecent
        {
            get
            {
                return m_EnergyPercent;
            }

            set
            {
                m_EnergyPercent = value;
            }
        }

        private void initWeelList(int i_NumOfWeels, float i_WeelsAirPressure, string i_WeelManufacturerName, int i_WeelMaxAirPressure)
        {
            m_Weels = new List<Weel>();
            for (int i = 0; i < i_NumOfWeels; i++)
            {
                Weel newWeel = new Weel(i_WeelManufacturerName, i_WeelsAirPressure, i_WeelMaxAirPressure);
                m_Weels.Add(newWeel);
            }
        }

        public List<Weel> Weels
        {
            get
            {
                return m_Weels;
            }

            set
            {
                m_Weels = value;
            }
        }

        public string LicenseNumber
        {
            get
            {
                return m_LicenseNumber;
            }

            set
            {
                m_LicenseNumber = value;
            }
        }

        public eVehicleStatus ThisVehicleStatus
        {
            get
            {
                return m_VehicleStatus;
            }

            set
            {
                m_VehicleStatus = value;
            }
        }

        public override int GetHashCode()
        {
            return this.m_LicenseNumber.GetHashCode(); 
        }

        protected string getInfo()
        {
            StringBuilder weelInfo = new StringBuilder();
            foreach (Weel weel in m_Weels)
            {
                weelInfo.Append(weel);
                weelInfo.Append(Environment.NewLine);
            }

            return string.Format(
                @"--General Information--
License Number: {1}
Model name: {0}
Client: [{4}]
Status: {3}
Energy meter: {2}%
-- weels information --
{5}",
                m_ModelName,
                m_LicenseNumber,
                m_EnergyPercent, 
                m_VehicleStatus,
                m_ClientOwner,
                weelInfo);
        }

        public override bool Equals(object i_other)
        {
            bool equals = false;
            if (i_other != null)
            {
                equals = this.GetHashCode() == i_other.GetHashCode(); 
            }

            return equals;
        }

        public static bool operator ==(Vehicle i_this, Vehicle i_other)
        {
            return Equals(i_this, i_other);
        }

        public static bool operator !=(Vehicle i_this, Vehicle i_other)
        {
            return !Equals(i_this, i_other);
        }
    }
}
