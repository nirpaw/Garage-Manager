﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public sealed class ElectricMotorcycle : ElectricVehicle
    {
        private const int m_NumOfWeels = 2;
        private const int m_WeelMaxAirPressure = 30;
        private const float m_MaxBatteryHours = 1.8f;
        private eMotorcycleLicenseType m_licenseType;
        private int m_EngineCapacity;

        public ElectricMotorcycle(eMotorcycleLicenseType i_licenseType, int i_EngineCapacity, float i_CurrentBatteryLeftHours, string i_ModelName, string i_LicenseNumber, float i_WeelsAirPressure, string i_OwnerName, string i_OwnwerPhone, string i_WeelManufacturerName)
        : base(i_CurrentBatteryLeftHours , m_MaxBatteryHours, i_ModelName, i_LicenseNumber, i_WeelsAirPressure, i_OwnerName, i_OwnwerPhone, m_NumOfWeels, i_WeelManufacturerName, m_WeelMaxAirPressure)
        {
            m_licenseType = i_licenseType;
            m_EngineCapacity = i_EngineCapacity; 
        }

        public override string ToString()
        {
            return 
                string.Format(
                @"{0}
-- Motorcycle properties -- 
License type: {1}
Engine: {2}cc",
                base.getInfo(), 
                m_licenseType, 
                m_EngineCapacity);
        }
    }
}
