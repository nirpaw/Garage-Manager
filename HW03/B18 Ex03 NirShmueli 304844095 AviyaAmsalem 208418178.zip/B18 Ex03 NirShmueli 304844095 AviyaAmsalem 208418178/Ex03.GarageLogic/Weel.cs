﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class Weel
    {
        private string m_ManufacturerName;
        private readonly float m_MaximumAirPressure;
        private float m_CurrentAirPressure;

        public Weel(string i_ManufacturerName, float i_CurrentAirPressure, float i_MaximumAirPressure)
        {
            m_ManufacturerName = i_ManufacturerName;
            m_MaximumAirPressure = i_MaximumAirPressure;
            CurrentAirPressure = i_CurrentAirPressure;
        }

        public float GetMaximumAirPressure()
        {
            return m_MaximumAirPressure;
        }

        public float CurrentAirPressure
        {
            get
            {
                return m_CurrentAirPressure;
            }

            set
            {
                if (value > m_MaximumAirPressure || value < 0)
                {
                    throw new ValueOutOfRangeException("Wheel air pressure", 0, m_MaximumAirPressure);
                }
                else
                {
                    m_CurrentAirPressure = value;
                }
            }
        }

        public void WheelInflating(float i_AirPressureToAdd)
        {
            CurrentAirPressure += i_AirPressureToAdd;
        }

        public override string ToString()
        {
            return string.Format("Manufacturer: \"{0}\" Air Pressure: {1} of {2}", m_ManufacturerName, m_CurrentAirPressure, m_MaximumAirPressure);
        }
    }
}
