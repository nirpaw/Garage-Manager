﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public enum eCarColor
    {
        Grey = 1, Blue, White, Black
    }

    public enum eNumOfDoors
    {
        Two = 2, Tree, Four, Five
    }
}
