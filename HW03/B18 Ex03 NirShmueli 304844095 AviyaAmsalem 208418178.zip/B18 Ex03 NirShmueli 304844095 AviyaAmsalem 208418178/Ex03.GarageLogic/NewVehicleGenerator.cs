﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public enum eEnergyMenuType
    {
        Fuel = 1, Electric
    }

    public enum eVehicleMenuType
    {
        Car = 1, Motorcycle, Truck
    }

    public class NewVehicleGenerator
    {
        public Vehicle AddElectricMotorcycle(eMotorcycleLicenseType i_LicenseType, int i_EngineCapacity, float i_CurrentBatteryLeftHours, string i_ModelName, string i_LicenseNumber, float i_WeelsAirPressure, string i_OwnerName, string i_OwnwerPhone, string i_WeelManufacturerName)
        {
            Vehicle newVehicel = new ElectricMotorcycle(i_LicenseType, i_EngineCapacity, i_CurrentBatteryLeftHours, i_ModelName, i_LicenseNumber, i_WeelsAirPressure, i_OwnerName, i_OwnwerPhone, i_WeelManufacturerName);
            return newVehicel;
        }

        public Vehicle AddElectricCar(eCarColor i_carColor, eNumOfDoors i_NumOfDoors, float i_CurrentBatteryLeftHours, string i_ModelName, string i_LicenseNumber, float i_WeelsAirPressure, string i_OwnerName, string i_OwnwerPhone, string i_WeelManufacturerName)
        {
            Vehicle newVehicel = new ElectricCar(i_carColor, i_NumOfDoors, i_CurrentBatteryLeftHours, i_ModelName, i_LicenseNumber, i_WeelsAirPressure, i_OwnerName, i_OwnwerPhone, i_WeelManufacturerName);
            return newVehicel;
        }

        public Vehicle AddNewFuelTruck(bool i_TruckIsCoold, float i_CargoVolume, float i_CurrentFuelLevel, string i_ModelName, string i_LicenseNumber, float i_WeelsAirPressure, string i_OwnerName, string i_OwnwerPhone, string i_WeelManufacturerName)
        {
            Vehicle newVehicel = new FuelTruck(i_TruckIsCoold, i_CargoVolume, i_CurrentFuelLevel, i_ModelName, i_LicenseNumber, i_WeelsAirPressure, i_OwnerName, i_OwnwerPhone, i_WeelManufacturerName);
            return newVehicel;
        }

        public Vehicle AddNewFuelMotorcycle(eMotorcycleLicenseType i_licenseType, int i_EngineCapacity, float i_CurrentFuelLevel, string i_ModelName, string i_LicenseNumber, float i_WeelsAirPressure, string i_OwnerName, string i_OwnwerPhone, string i_WeelManufacturerName)
        {
            Vehicle newVehicel = new FuelMotorcycle(i_licenseType, i_EngineCapacity, i_CurrentFuelLevel, i_ModelName, i_LicenseNumber, i_WeelsAirPressure, i_OwnerName, i_OwnwerPhone, i_WeelManufacturerName);
            return newVehicel;
        }

        public Vehicle AddNewFuelCar(eCarColor i_CarColor, eNumOfDoors i_NumOfDoors, float i_CurrentFuelLevel, string i_ModelName, string i_LicenseNumber, float i_WeelsAirPressure, string i_OwnerName, string i_OwnwerPhone, string i_WeelManufacturerName)
        {
            Vehicle newVehicel = new FuelCar(i_CarColor, i_NumOfDoors, i_CurrentFuelLevel, i_ModelName, i_LicenseNumber, i_WeelsAirPressure, i_OwnerName, i_OwnwerPhone, i_WeelManufacturerName);
            return newVehicel;
        }
    }
}
