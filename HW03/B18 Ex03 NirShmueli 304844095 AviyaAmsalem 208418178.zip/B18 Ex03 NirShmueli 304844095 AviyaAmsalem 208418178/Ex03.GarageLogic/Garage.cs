﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class Garage
    {
        private List<Vehicle> m_vehiclesInGarge;

        public Garage()
        {
            m_vehiclesInGarge = new List<Vehicle>();
        }

        public bool VehicleIsInGarage(string i_License)
        {
            bool isExist = false;
            foreach(Vehicle existVehicle in m_vehiclesInGarge)
            {
                if(existVehicle.LicenseNumber == i_License)
                {
                    isExist = true;
                    break;
                }
            }

            return isExist;
        }     
        
        public void AddVehicleToGarage(Vehicle i_vehicle)
        {
                m_vehiclesInGarge.Add(i_vehicle);
        }

        public string GetLicenseNumberByStatus(eVehicleStatus i_status)
        {
            StringBuilder sb = new StringBuilder();
            int counter = 0;
            foreach (Vehicle vehicle in m_vehiclesInGarge)
            {
                if (vehicle.ThisVehicleStatus == i_status)
                {
                    sb.Append(++counter);
                    sb.Append(") ");
                    sb.Append(vehicle.LicenseNumber);
                    sb.Append(Environment.NewLine);
                }
            }

            if(counter == 0)
            {
                sb.Append("There is no vehicles in this status");
            }

            string strListOfVehicles = sb.ToString();
            return strListOfVehicles;
        }

        public Vehicle GetVehicleFromLicenseNumber(string i_License)
        {
            Vehicle returnVehicle = null;
            foreach (Vehicle vehicle in m_vehiclesInGarge)
            {
                if (vehicle.LicenseNumber == i_License)
                {
                    returnVehicle = vehicle;
                    break;
                }
            }

            if (returnVehicle == null)
            {
                throw new Exception("The license number is not exist");
            }

            return returnVehicle;
        }

        public void ChangeVehicleStatus(string i_License, eVehicleStatus i_newStatus)
        {
            Vehicle thisVehicle = GetVehicleFromLicenseNumber(i_License);
            if (thisVehicle != null)
            {
                thisVehicle.ThisVehicleStatus = i_newStatus;
            }
        }      

        public void AddAirPressureToMax(string i_License)
        {
            Vehicle thisVehicle = GetVehicleFromLicenseNumber(i_License);
            if(thisVehicle != null)
            {
                foreach (Weel weel in thisVehicle.Weels)
                {
                    weel.WheelInflating(weel.GetMaximumAirPressure() - weel.CurrentAirPressure);
                }
            }
        }   

        public void Refuel(string i_License, efuelType i_fuelType, float i_LitersToAdd)
        {
            Vehicle thisVehicle = GetVehicleFromLicenseNumber(i_License) as FuelVehicle;
            if(thisVehicle != null)
            {
                ((FuelVehicle)thisVehicle).Refuel(i_LitersToAdd, i_fuelType);
            }
            else
            {
                throw new ArgumentException("The vehicle is not powered by fuel");
            }
        }

        public void Charge(string i_License, float i_MinutesToAdd)
        {
            float hoursToAdd = i_MinutesToAdd / 60;
            Vehicle thisVehicle = GetVehicleFromLicenseNumber(i_License) as ElectricVehicle;
            if (thisVehicle != null)
            {
                ((ElectricVehicle)thisVehicle).ChargeBattery(hoursToAdd);
            }
            else
            {
                throw new ArgumentException("The vehicle is not powered by electric");
            }
        }

        public string GetFullInfoOfVehicel(string i_License)
        {
            Vehicle thisVehicle = GetVehicleFromLicenseNumber(i_License);
            string vehicelInfo = null;
            if (thisVehicle != null)
            {
                vehicelInfo = thisVehicle.ToString();
            }

            return vehicelInfo;
        }
    }
}
