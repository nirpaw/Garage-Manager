﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public sealed class ElectricCar : ElectricVehicle
    {
        private const int m_NumOfWeels = 4;
        private const int m_WeelMaxAirPressure = 32;
        private const float m_MaxBatteryHours = 3.2f;
        private eCarColor m_CarColor;
        private eNumOfDoors m_NumOfDoors;

        public ElectricCar(eCarColor i_carColor, eNumOfDoors i_NumOfDoors, float i_CurrentBatteryLeftHours, string i_ModelName, string i_LicenseNumber, float i_WeelsAirPressure, string i_OwnerName, string i_OwnwerPhone, string i_WeelManufacturerName)
            : base(i_CurrentBatteryLeftHours, m_MaxBatteryHours,i_ModelName, i_LicenseNumber, i_WeelsAirPressure, i_OwnerName, i_OwnwerPhone, m_NumOfWeels, i_WeelManufacturerName, m_WeelMaxAirPressure)
        {
            m_CarColor = i_carColor;
            m_NumOfDoors = i_NumOfDoors;
        }

        public override string ToString()
        {
            return string.Format(@"{0}
-- Car properties --
Color: {1}
Doors: {2} ", base.getInfo(), m_CarColor, m_NumOfDoors);
        }
    }
}
