﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public class Client
    {
        private string m_ClientName;
        private string m_ClientPhoneNumber;

        public Client(string i_ClientName, string i_ClientPhoneNumber)
        {
            m_ClientName = i_ClientName;
            m_ClientPhoneNumber = i_ClientPhoneNumber;
        }

        public override string ToString()
        {
            return string.Format("Name: {0}, Phone: {1}", m_ClientName, m_ClientPhoneNumber);
        }
    }
}
