﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public enum efuelType
    {
        Octan98 = 1, Octan96, Octan95, Soler
    }

    public abstract class FuelVehicle : Vehicle
    {
        private readonly float m_MaxFuelLevel;
        private efuelType m_FuelType;
        private float m_CurrentFuelLevel;

        public FuelVehicle(efuelType i_FuelType, float i_CurrentFuelLevel, float i_maxFuelLevel, string i_ModelName, string i_LicenseNumber, float i_WeelsAirPressure, string i_OwnerName, string i_OwnwerPhone, int i_numOfWeels, string i_WeelManufacturerName, int i_WeelMaxAirPressure)
            : base(i_ModelName, i_LicenseNumber,  i_WeelsAirPressure, i_OwnerName, i_OwnwerPhone, i_numOfWeels, i_WeelManufacturerName, i_WeelMaxAirPressure)
        {
            m_FuelType = i_FuelType;
            m_MaxFuelLevel = i_maxFuelLevel;
            CurrentFuelLevel = i_CurrentFuelLevel;
        }

        public float GetMaxFuleLevel()
        {
            return m_MaxFuelLevel;
        }

        public float CurrentFuelLevel
        {
            get
            {
                return m_CurrentFuelLevel;
            }

            set
            {
                if (value > m_MaxFuelLevel || value < 0)
                {
                    throw new ValueOutOfRangeException("Fuel tank", 0, m_MaxFuelLevel);
                }
                else
                {
                    m_CurrentFuelLevel = value;
                    base.EnergyPrecent = m_CurrentFuelLevel * (100 / m_MaxFuelLevel);
                }
            }
        }

        public void Refuel(float i_LiterToAdd, efuelType i_IntoFuelType)
        {
            if (i_IntoFuelType != m_FuelType)
            {
                throw new ArgumentException(string.Format("Wrong fuel type, must be {0}", m_FuelType));
            }
            else
            {
                CurrentFuelLevel += i_LiterToAdd;
            }
        }

        protected string GetInfo()
        {
            return string.Format(
                @"{0}-- Fuel unit information-- 
Type: {1}
Capacity: {2} of {3} liter", 
                base.getInfo(),
                m_FuelType,
                m_CurrentFuelLevel, 
                m_MaxFuelLevel);
        }
    }
}
