﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public sealed class FuelCar : FuelVehicle
    {
        private const efuelType m_FuelType = efuelType.Octan98;
        private const float m_MaxFuelLevel = 45;
        private const int m_WeelMaxAirPressure = 32;
        private const int m_NumOfWeels = 4;
        private eCarColor m_CarColor;
        private eNumOfDoors m_NumOfDoors;
    
        public FuelCar(eCarColor i_CarColor, eNumOfDoors i_NumOfDoors, float i_CurrentFuelLevel, string i_ModelName, string i_LicenseNumber, float i_WeelsAirPressure, string i_OwnerName, string i_OwnwerPhone, string i_WeelManufacturerName)
            : base(m_FuelType, i_CurrentFuelLevel, m_MaxFuelLevel, i_ModelName, i_LicenseNumber, i_WeelsAirPressure, i_OwnerName, i_OwnwerPhone, m_NumOfWeels, i_WeelManufacturerName, m_WeelMaxAirPressure)
        {
            m_CarColor = i_CarColor;
            m_NumOfDoors = i_NumOfDoors;
        }

        public override string ToString()
        {
            return string.Format(
                @"{0}
-- Car properties --
Color: {1}
Doors: {2} ",
                base.GetInfo(),
                m_CarColor,
                m_NumOfDoors);
        }
    }
}
