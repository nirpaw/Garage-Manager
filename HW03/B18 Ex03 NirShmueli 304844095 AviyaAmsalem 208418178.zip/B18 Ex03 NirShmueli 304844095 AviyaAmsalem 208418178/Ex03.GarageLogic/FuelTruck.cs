﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03.GarageLogic
{
    public sealed class FuelTruck : FuelVehicle
    {
        private const int m_NumOfWeels = 12;
        private const efuelType m_FuelType = efuelType.Soler;
        private const float m_maxFuelLevel = 115;
        private const int m_WeelMaxAirPressure = 28;
        private bool m_TruckIsCoold;
        private float m_CargoVolume;

        public FuelTruck(bool i_TruckIsCoold, float i_CargoVolume, float i_CurrentFuelLevel, string i_ModelName, string i_LicenseNumber, float i_WeelsAirPressure, string i_OwnerName, string i_OwnwerPhone, string i_WeelManufacturerName)
    : base(m_FuelType, i_CurrentFuelLevel, m_maxFuelLevel, i_ModelName, i_LicenseNumber, i_WeelsAirPressure, i_OwnerName, i_OwnwerPhone, m_NumOfWeels, i_WeelManufacturerName, m_WeelMaxAirPressure)
        {
            m_TruckIsCoold = i_TruckIsCoold;
            m_CargoVolume = i_CargoVolume;
        }

        public override string ToString()
        {
            return string.Format(
                @"{0}
-- Truck properties --
Cargo volume: {1}
The truck is {2} cooled",
                base.GetInfo(),
                m_CargoVolume, 
                m_TruckIsCoold ? string.Empty : "NOT");
        }
    }
}
